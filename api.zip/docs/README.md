# GM Celular - Kit Banco (cPanel) - versão fácil

Este pacote cria um "backend" bem simples em PHP + MariaDB/MySQL (do cPanel) para salvar:
- produtos
- categorias
- configurações da loja (tema/textos)

## 1) Subir arquivos
Envie a pasta `public_html/api/` para: `public_html/api/` do seu site.

## 2) Criar o banco e tabelas
No cPanel:
- MySQL Databases: crie um banco e um usuário e dê ALL PRIVILEGES
- phpMyAdmin > selecione o banco > aba SQL > cole o conteúdo de `sql/init.sql`

## 3) Configurar conexão
Edite `public_html/api/db.php` e preencha:
- $db (nome completo do banco no cPanel, geralmente com prefixo)
- $user
- $pass

## 4) Testar endpoints
Abra no navegador:

- Listar categorias:
  /api/categories.php

- Listar produtos:
  /api/products.php

- Ver config:
  /api/store_config.php

### Inserir produto (teste rápido no console do navegador)
fetch("/api/products.php", {
  method: "POST",
  headers: {"Content-Type":"application/json"},
  body: JSON.stringify({name:"iPhone 11", price:1899})
}).then(r=>r.json()).then(console.log)

## Observação importante
Seu front-end atual usa localStorage. Para "ligar" no banco, você precisa trocar/ adicionar fetch para esses endpoints.
Se você quiser, me diga onde está o arquivo do admin no projeto (ou me envie o código) e eu te passo o patch certinho.
