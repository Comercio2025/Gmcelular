<?php
require __DIR__ . "/db.php";
require __DIR__ . "/helpers.php";

// Endpoint: /api/categories.php
// GET -> lista
// POST -> cria
// PUT -> atualiza
// DELETE -> remove (por id)

$method = $_SERVER["REQUEST_METHOD"];

if ($method === "GET") {
  $stmt = $pdo->query("SELECT * FROM categories ORDER BY name ASC");
  gm_ok($stmt->fetchAll());
}

if ($method === "POST") {
  $d = gm_read_json_body();
  if (empty($d["name"])) gm_fail("Campo obrigatório: name");

  $stmt = $pdo->prepare("INSERT INTO categories (name) VALUES (?)");
  $stmt->execute([$d["name"]]);
  gm_ok(["id" => (int)$pdo->lastInsertId()]);
}

if ($method === "PUT") {
  $d = gm_read_json_body();
  if (empty($d["id"])) gm_fail("Informe o id");
  if (empty($d["name"])) gm_fail("Campo obrigatório: name");

  $stmt = $pdo->prepare("UPDATE categories SET name = ? WHERE id = ?");
  $stmt->execute([$d["name"], $d["id"]]);
  gm_ok();
}

if ($method === "DELETE") {
  $id = $_GET["id"] ?? null;
  if (!$id) gm_fail("Informe ?id=...");
  $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
  $stmt->execute([$id]);
  gm_ok();
}

gm_fail("Método não permitido", 405);
