<?php
require __DIR__ . "/db.php";
require __DIR__ . "/helpers.php";

// Endpoint: /api/store_config.php
// GET  -> retorna config (JSON)
// POST -> salva config (JSON)

$method = $_SERVER["REQUEST_METHOD"];

if ($method === "GET") {
  $stmt = $pdo->query("SELECT data FROM store_config WHERE id = 1 LIMIT 1");
  $row = $stmt->fetch();
  $data = $row ? json_decode($row["data"], true) : new stdClass();
  gm_ok($data);
}

if ($method === "POST") {
  $d = gm_read_json_body();
  $encoded = json_encode($d, JSON_UNESCAPED_UNICODE);
  if ($encoded === false) gm_fail("Falha ao serializar JSON", 500);

  $stmt = $pdo->prepare("UPDATE store_config SET data = ? WHERE id = 1");
  $stmt->execute([$encoded]);
  gm_ok();
}

gm_fail("Método não permitido", 405);
