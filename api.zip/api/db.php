<?php
// GM Celular - Catálogo Digital
// Conexão PDO com MySQL/MariaDB (cPanel)
// 1) Preencha os dados abaixo (host, db, user, pass)
// 2) Suba este arquivo em: public_html/api/db.php

header("Content-Type: application/json; charset=utf-8");

$host = "localhost";
$db   = "gmso3652_gm_catalogo";        // ex: gmso3652_gm_catalogo
$user = "gmso3652_gmcatalogo";      // ex: gmso3652_user
$pass = "Comercio@2025";        // senha do usuário MySQL

try {
  $pdo = new PDO(
    "mysql:host=$host;dbname=$db;charset=utf8mb4",
    $user,
    $pass,
    [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]
  );
} catch (Exception $e) {
  http_response_code(500);
  echo json_encode(["success" => false, "error" => "Erro ao conectar no banco"]);
  exit;
}
