<?php
// Funções auxiliares para padronizar respostas e ler JSON do corpo
function gm_read_json_body() {
  $raw = file_get_contents("php://input");
  if (!$raw) return [];
  $data = json_decode($raw, true);
  if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(["success" => false, "error" => "JSON inválido"]);
    exit;
  }
  return $data;
}

function gm_ok($data = null) {
  $payload = ["success" => true];
  if (!is_null($data)) $payload["data"] = $data;
  echo json_encode($payload, JSON_UNESCAPED_UNICODE);
  exit;
}

function gm_fail($msg, $code = 400) {
  http_response_code($code);
  echo json_encode(["success" => false, "error" => $msg], JSON_UNESCAPED_UNICODE);
  exit;
}
