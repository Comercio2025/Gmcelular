<?php
require __DIR__ . "/db.php";
require __DIR__ . "/helpers.php";

// Endpoint: /api/products.php
// GET  -> lista produtos
// POST -> cria produto
// PUT  -> atualiza produto
// DELETE -> remove produto (por id)

$method = $_SERVER["REQUEST_METHOD"];

if ($method === "GET") {
  $stmt = $pdo->query("SELECT p.*, c.name AS category_name FROM products p
                       LEFT JOIN categories c ON c.id = p.category_id
                       ORDER BY p.id DESC");
  gm_ok($stmt->fetchAll());
}

if ($method === "POST") {
  $d = gm_read_json_body();

  if (empty($d["name"])) gm_fail("Campo obrigatório: name");
  if (!isset($d["price"])) gm_fail("Campo obrigatório: price");

  $stmt = $pdo->prepare("INSERT INTO products (name, price, category_id, image, description, status, brand, condition_label)
                         VALUES (:name, :price, :category_id, :image, :description, :status, :brand, :condition_label)");
  $stmt->execute([
    ":name" => $d["name"],
    ":price" => $d["price"],
    ":category_id" => $d["category_id"] ?? null,
    ":image" => $d["image"] ?? "",
    ":description" => $d["description"] ?? "",
    ":status" => $d["status"] ?? "",
    ":brand" => $d["brand"] ?? "",
    ":condition_label" => $d["condition_label"] ?? "",
  ]);

  gm_ok(["id" => (int)$pdo->lastInsertId()]);
}

if ($method === "PUT") {
  $d = gm_read_json_body();
  $id = $d["id"] ?? null;
  if (!$id) gm_fail("Informe o id");

  $stmt = $pdo->prepare("UPDATE products SET
      name = :name,
      price = :price,
      category_id = :category_id,
      image = :image,
      description = :description,
      status = :status,
      brand = :brand,
      condition_label = :condition_label
    WHERE id = :id");
  $stmt->execute([
    ":id" => $id,
    ":name" => $d["name"] ?? "",
    ":price" => $d["price"] ?? 0,
    ":category_id" => $d["category_id"] ?? null,
    ":image" => $d["image"] ?? "",
    ":description" => $d["description"] ?? "",
    ":status" => $d["status"] ?? "",
    ":brand" => $d["brand"] ?? "",
    ":condition_label" => $d["condition_label"] ?? "",
  ]);

  gm_ok();
}

if ($method === "DELETE") {
  // aceitar ?id=123
  $id = $_GET["id"] ?? null;
  if (!$id) gm_fail("Informe ?id=...");
  $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
  $stmt->execute([$id]);
  gm_ok();
}

gm_fail("Método não permitido", 405);
